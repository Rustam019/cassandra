package com.dailyCodebuffer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value ="users")
public class UserController
{
   
    
    
   @Autowired 
   private UserService userService; 
   
   @GetMapping("/user")
   public String getData()
   {
       return "User service is up now";
   }
   
   @PostMapping("/")
   public User saveUser(@RequestBody User user)
   {
       return userService.saveUser(user);
   }
    
   
   
   @GetMapping("/")
   public List<User> findAllUsers()
   {
       return userService.getAllUsers();
   }
   
   
   
   @GetMapping("/{id}")
   public ResponseTemplateVO getUserWithDepartment(@PathVariable("id") Long userId)
   {
       return userService.getUserWithDepartment(userId);
   }
   
   
}
