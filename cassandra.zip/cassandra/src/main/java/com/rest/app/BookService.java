package com.rest.app;

import java.util.List;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;


@Service
public interface BookService  
{

    
 public  String DeleteById(int bookId) throws NotFoundException; 
 public Book UpdateBRecord(Book bookRecord) throws NotFoundException;
 public List<Book> findAllBooks();
 public Book  AddBRecord(Book boook);
}
