package com.rest.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;


@Configuration
public class bookServiceImpl implements BookService
{
    
    
    
    
    @Override
    public List<Book> findAllBooks() {
	List<Book> list = new ArrayList<>();
	Book book = new Book();


	try {
	    Session session = getSession() ; 
	    List<Row> all = session.execute("select * from book_records").all();
	    for(Row row:all) 
	    {  
		book = new Book(row.getInt("bookId"),row.getString("name"),row.getString("summary"),row.getInt("rating"));
		list.add(book);
	    }
	}
	catch(Exception e)
	{
	    System.out.println(e);
	}

	System.out.println(list.toString());
	return  list;  
    }
  

    @Override
    public String DeleteById(int bookId) throws NotFoundException  {
	Session session = getSession() ; 
	    StringBuilder str = new  StringBuilder("delete from book_records where bookid=").append(bookId);
	    String query =str.toString();
	    session.execute(query);
	    StringBuilder string = new  StringBuilder("select * from book_records where bookid=").append(bookId);
	    String qry =string.toString();
	    List<Row> deletedResult = session.execute(qry).all();
	    if(!deletedResult.isEmpty())
	    {
		throw new NotFoundException();
	    }
	    return "Rescord got deleted";
    }

    @Override
    public Book UpdateBRecord(Book bookRecord) throws NotFoundException 
    {
	Book boook = new Book();
	if(bookRecord==null || bookRecord.getBookId() == 0 )
	{
	    throw new NotFoundException();
	}
	Session session = getSession() ; 
	StringBuilder str = new  StringBuilder("select * from book_records where bookid=").append(bookRecord.getBookId());
	String query =str.toString();
	List<Row> getbook = session.execute(query).all();
	if(getbook.isEmpty())
	{
	    throw new NotFoundException();
	}  
	boook.setBookId(bookRecord.getBookId());   
	boook.setName(bookRecord.getName());
	boook.setSummary(bookRecord.getSummary());
	boook.setRating(bookRecord.getRating()); 
	PreparedStatement prepare = session.prepare("insert into book_records(bookid,name,summary,rating)values(?,?,?,?)");	    
	BoundStatement bond = prepare.bind(boook.getBookId(),boook.getName(),boook.getSummary(),boook.getRating());
        session.execute(bond);
     
	return boook;
	
    }
   
    
    
    
    
    
    
    public Session getSession()
    {

	Cluster cluster = null ; 
	Session session1 = null;

	cluster = cluster.builder().addContactPoint("127.0.0.1").build(); 
	String	  clusterName = cluster.getClusterName(); 
	Session session =  cluster.connect("espro");
	return session;

    }


    @Override
    public Book AddBRecord(Book book)
    {
	
	Book bok = new Book();
	try {
	    Session session = getSession() ;     
	    PreparedStatement prepare = session.prepare("insert into book_records(bookid,name,rating,summary)values(?,?,?,?)");	    
	    BoundStatement bond = prepare.bind(book.getBookId(),book.getName(),book.getRating(),book.getSummary());
	    List<Row> all = session.execute(bond).all();

	    for(Row row:all) 
	    {  
		bok = new Book(row.getInt("bookId"),row.getString("name"),row.getString("summary"),row.getInt("rating"));
	    }
	}
	catch(Exception e)
	{
	    System.out.println(e);
	}

	System.out.println(book.toString());
	return bok;
    }

    

    
}
