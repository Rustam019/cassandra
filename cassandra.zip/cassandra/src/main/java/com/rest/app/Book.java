package com.rest.app;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.lang.NonNull;

import com.datastax.driver.mapping.annotations.Table;

//@Entity
@Table(name = "book_records")
public class Book
{

    @PrimaryKey 
    private int bookId;  
    
    @NonNull
    private String name;
    
    @NonNull
    private String summary;
    
    private int rating;

    public Book(int bookId, String name, String summary, int rating) {
	super();
	this.bookId = bookId;
	this.name = name;
	this.summary = summary;
	this.rating = rating;
    }

    public Book() {
	super();
	// TODO Auto-generated constructor stub
    }
    
    
    

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
	return "Book [bookId=" + bookId + ", name=" + name + ", summary=" + summary + ", rating=" + rating + "]";
    }
    
    
    
}
