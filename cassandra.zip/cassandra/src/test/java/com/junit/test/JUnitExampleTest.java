package com.junit.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.rest.app.Book;
import com.rest.app.BookController;
import com.rest.app.BookService;
import com.rest.app.bookServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class JUnitExampleTest 
{
    
    @Autowired
    BookService bookService;
    
    
     @Mock
     bookServiceImpl sericeImpl;

     /*
      * @Test public void demotestMethod() { assertTrue(true); }
      */
     
     
     
    @Test
   public void getAllRecoirds_success() 
     {
 	when(sericeImpl.findAllBooks()).thenReturn(Stream.of(new Book(1,"Atomic Habits","how to build better habits",8)).collect(Collectors.toList()));
        assertEquals(1,bookService.findAllBooks().size() );
 	
 	
// 	book=new Book(1,"Atomic Habits","how to build better habits",8);
// 	
//        bookService.AddBRecord(book);
// 	List<List<Book>> bookById = controller.getBookById(1);
// 	boolean empty = bookById.isEmpty();
// 	assertThat(empty).isTrue();
    
	  
     }
}
